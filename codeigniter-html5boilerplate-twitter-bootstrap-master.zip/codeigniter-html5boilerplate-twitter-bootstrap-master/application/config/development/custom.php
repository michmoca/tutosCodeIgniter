<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['site_title'] = 'title';
$config['site_description'] = 'description';
$config['site_author'] = 'arny';
$config['site_keywords'] = 'key1, key2';


/* End of file custom.php */
/* Location: ./application/config/development/custom.php */