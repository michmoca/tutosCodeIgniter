<footer id="footer" class="container">
	<div class="row">
		<div class="span6">MY AWESOME FOOTER</div>
		<div class="span6">HI</div>
	</div>
	
</footer>