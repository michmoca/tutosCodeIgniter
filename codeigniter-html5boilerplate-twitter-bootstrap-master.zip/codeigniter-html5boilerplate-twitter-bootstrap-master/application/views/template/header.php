<header id="header" class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container">
     <?php echo $nav?>
    </div>
  </div>
</header>