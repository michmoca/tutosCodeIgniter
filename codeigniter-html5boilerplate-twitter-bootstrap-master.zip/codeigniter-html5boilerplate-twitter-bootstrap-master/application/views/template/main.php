<?php echo $basejs?>
<?php echo $header ?>
<div id="main" role="main" class="row">
	<?php echo $content_body ?>
</div>
<?php echo $footer ?>
