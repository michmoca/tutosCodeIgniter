<ul class="nav" >
	<li class="<?php echo isActive($pageName,"home")?>"><a href="<?php echo  base_url()?>">Home</a></li>
	<li class="<?php echo isActive($pageName,"about")?>"><a href="<?php echo  base_url()?>">Link</a></li>
	<li class="<?php echo isActive($pageName,"about")?>"><a href="<?php echo  base_url()?>">Link</a></li>
	<li class="<?php echo isActive($pageName,"about")?>"><a href="<?php echo  base_url()?>">Link</a></li>
	<li class="<?php echo isActive($pageName,"about")?>"><a href="<?php echo  base_url()?>">Link</a></li>
	<li class="<?php echo isActive($pageName,"about")?>"><a href="<?php echo  base_url()?>">Link</a></li>
</ul>